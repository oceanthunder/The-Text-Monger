import csv
import spacy
from textmonger.power import Power
from spacy import displacy
from pyfiglet import Figlet
from textmonger.readability import Readability

def main():
    print(ascii('The Text Monger'))
    
    text = get_lines()

    print("\n" + "="*80)
    print(f"{' ' * 30}Readability Analysis")
    print("="*80)
    
    analysis = Readability(text)
    print(analysis.analyze())

    print("\n" + "="*80)
    print(f"{' ' * 30}Power Words Distribution")
    print("="*80)
    
    strong = Power('power_words.csv', text)
    cat_count = strong.find()
    ascii_chart = strong.ascii_pie_chart(cat_count)
    print('\n' + ascii_chart)

    print("\n" + "="*80)
    print(f"{' ' * 30}Named Entity Recognition (NER)")
    print("="*80)
    
    ner(text)

def ascii(text):
    f = Figlet()
    return f.renderText(text)

def get_lines():
    print("Enter Text to analyze (type 'END' on a new line to finish):")
    lines = []
    while True:
        line = input()
        if line.strip().upper() == 'END':
            break
        lines.append(line)
    text = "\n".join(lines)
    return text

def ner(text):
    nlp = spacy.load('en_core_web_sm')
    doc = nlp(text)
    displacy.serve(doc, style = 'ent')

if __name__ == "__main__":
    main()
